# config.py

FS = 100  # Frecuencia de muestreo (100Hz)
INPUT_LENGTH = 1000  # 10 segundos
ECG_PATH = r"C:\Users\cuent\Desktop\CNN HACKHATON\ecg-system\data"
CSV_PATH = "data/ptbxl_database.csv"
NUM_CLASSES = 5  # Cambiar según número de clases que uses
